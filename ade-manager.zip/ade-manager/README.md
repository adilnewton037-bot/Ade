# Ade Manager
Ade backend ko phone se manage karne wali Android app.
Features: Dashboard, Data (add/view/delete), Users, Files (upload/delete), Access Rules.

## APK banana (GitHub se)
1. Naya repo banao, `ade-manager.zip` upload karo (repo root me, extract na karo).
2. `.github/workflows/build-apk.yml` bhi create karo (zip ke andar wali file ka code paste karo).
3. Actions tab > run complete hone ke baad Artifacts se `ade-manager-apk` download karo.
4. Zip kholkar `app-debug.apk` install karo.

App kholkar apna server URL (https://...) aur Admin key daalo.
